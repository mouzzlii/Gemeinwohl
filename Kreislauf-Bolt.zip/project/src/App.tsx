import { useState } from 'react';
import {
  QrCode,
  ArrowLeftRight,
  Leaf,
  Clock,
  Search,
  Gift,
  Briefcase,
  ShieldAlert,
  Building2,
  Users,
  PlusCircle,
  X,
  TrendingDown,
  Wallet,
  Handshake,
  MapPin,
  ChevronRight,
  Coins,
} from 'lucide-react';
import QrModal from '@/components/QrModal';
import CreateModal from '@/components/CreateModal';

export type Role = 'citizen' | 'business' | 'institution' | 'social';
export type Tab = 'wallet' | 'marketplace' | 'impact';
export type MarketplaceFilter = 'all' | 'search' | 'gift' | 'service' | 'goods';

export interface MarketplaceItem {
  id: number;
  title: string;
  type: Exclude<MarketplaceFilter, 'all'>;
  category: string;
  price: string;
  author: string;
  location: string;
}

export interface Transaction {
  id: number;
  type: 'receive' | 'send';
  partner: string;
  amount: string;
  date: string;
  category: string;
}

const RANK_CAP = 1000.0;
const USER_BALANCE = 340.5;
const FREE_DAYS_LEFT = 14;
const DEMURRAGE_RATE = '-0.4% nach Ablauf';

const ROLE_INFO: Record<Role, { label: string; icon: typeof Users; tone: string }> = {
  citizen: { label: 'Bürger', icon: Users, tone: 'emerald' },
  business: { label: 'Betrieb / B2B', icon: Briefcase, tone: 'amber' },
  institution: { label: 'Institution', icon: Building2, tone: 'blue' },
  social: { label: 'Sozialeinrichtung', icon: ShieldAlert, tone: 'violet' },
};

const ROLE_DESCRIPTIONS: Record<Role, { title: string; body: string; tone: string }> = {
  citizen: {
    title: 'Bürger-Modus',
    body: 'Voller Zugriff auf Marktplatz, Tausch und Nachbarschaftshilfe.',
    tone: 'emerald',
  },
  business: {
    title: 'Betriebs- & B2B-Modus',
    body: 'Annahme von GWP für Waren, B2B-Netzwerk & Dienstleistungsaustausch.',
    tone: 'amber',
  },
  institution: {
    title: 'Institutionen-Modus',
    body: 'Entscheidungen treffen & Begleichung von Gebühren/Strafen in Punkten.',
    tone: 'blue',
  },
  social: {
    title: 'Soziale Einrichtung',
    body: 'Kooperation mit Institutionen & Übernahme offline-basierter Rollen.',
    tone: 'violet',
  },
};

const INITIAL_ITEMS: MarketplaceItem[] = [
  {
    id: 1,
    title: 'Anhänger für Holztransport (für 1 Tag)',
    type: 'search',
    category: 'Dienstleistung / Leihen',
    price: '30 GWP oder Tausch gegen Holz',
    author: 'Markus H.',
    location: 'Yspertal',
  },
  {
    id: 2,
    title: 'Gut erhaltene Kinder-Skier (Größe 120)',
    type: 'gift',
    category: 'Zu verschenken',
    price: '0 GWP (Geschenk)',
    author: 'Karin B.',
    location: 'Altenmarkt',
  },
  {
    id: 3,
    title: 'E-Bike Inspektion & Bremsen-Check',
    type: 'service',
    category: 'Betriebe & Dienstleistung',
    price: '45 GWP',
    author: 'Fahrrad-Rettung',
    location: 'Yspertal Zentrum',
  },
  {
    id: 4,
    title: 'Bio-Sauerteigbrot aus hofeigenem Getreide',
    type: 'goods',
    category: 'Regionale Lebensmittel',
    price: '8 GWP oder gleichwertiger Tausch',
    author: 'Bio-Hof Schauer',
    location: 'Ybbs an der Donau',
  },
];

const RECENT_TRANSACTIONS: Transaction[] = [
  {
    id: 1,
    type: 'receive',
    partner: 'Bio-Hofladen Yspertal',
    amount: '+45.00',
    date: 'Heute, 14:15',
    category: 'Lebensmittel',
  },
  {
    id: 2,
    type: 'send',
    partner: 'Gemeinde Yspertal (Gebührenausgleich)',
    amount: '-25.00',
    date: 'Gestern, 09:30',
    category: 'Institutionell',
  },
  {
    id: 3,
    type: 'receive',
    partner: 'Nachbarschaftshilfe',
    amount: '+60.00',
    date: '14. Okt',
    category: 'Tausch',
  },
];

const TONE_CLASSES: Record<string, { bg: string; text: string; border: string }> = {
  emerald: { bg: 'bg-emerald-50', text: 'text-emerald-900', border: 'border-emerald-100' },
  amber: { bg: 'bg-amber-50', text: 'text-amber-900', border: 'border-amber-100' },
  blue: { bg: 'bg-blue-50', text: 'text-blue-900', border: 'border-blue-100' },
  violet: { bg: 'bg-violet-50', text: 'text-violet-900', border: 'border-violet-100' },
};

function App() {
  const [activeRole, setActiveRole] = useState<Role>('citizen');
  const [activeTab, setActiveTab] = useState<Tab>('wallet');
  const [marketplaceFilter, setMarketplaceFilter] = useState<MarketplaceFilter>('all');
  const [showQrModal, setShowQrModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [marketplaceItems, setMarketplaceItems] = useState<MarketplaceItem[]>(INITIAL_ITEMS);

  const roleDesc = ROLE_DESCRIPTIONS[activeRole];
  const roleTone = TONE_CLASSES[roleDesc.tone];

  const filteredItems = marketplaceItems.filter(
    (item) => marketplaceFilter === 'all' || item.type === marketplaceFilter
  );

  const handleCreate = (data: { title: string; type: MarketplaceItem['type']; price: string }) => {
    setMarketplaceItems((prev) => [
      {
        id: prev.length + 1,
        title: data.title,
        type: data.type,
        category:
          data.type === 'search'
            ? 'Ich suche nach...'
            : data.type === 'gift'
              ? 'Zu verschenken'
              : data.type === 'service'
                ? 'Dienstleistung'
                : 'Ware / Produkt',
        price: data.price,
        author: 'Du',
        location: 'Yspertal',
      },
      ...prev,
    ]);
    setShowCreateModal(false);
  };

  return (
    <div className="min-h-screen bg-[var(--color-gemeinwohl-bg)] text-[var(--color-gemeinwohl-text)] antialiased relative">
      {/* HEADER & ROLLEN-UMSCHALTER */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-20 shadow-sm">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[var(--color-gemeinwohl-primary)] flex items-center justify-center text-white shadow-sm">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Gemeinwohl-Protokoll</h1>
              <p className="text-xs text-gray-500">Regionales Ökosystem Yspertal</p>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-1 bg-gray-100 p-1 rounded-xl text-xs">
            {(Object.keys(ROLE_INFO) as Role[]).map((role) => {
              const Info = ROLE_INFO[role];
              return (
                <button
                  key={role}
                  onClick={() => setActiveRole(role)}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                    activeRole === role
                      ? 'bg-white shadow-sm text-[var(--color-gemeinwohl-primary)]'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <Info.icon className="w-3.5 h-3.5 inline mr-1" /> {Info.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-6 flex space-x-8 border-t border-gray-100 text-sm font-medium overflow-x-auto">
          <button
            onClick={() => setActiveTab('wallet')}
            className={`py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'wallet'
                ? 'border-[var(--color-gemeinwohl-primary)] text-[var(--color-gemeinwohl-primary)]'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            Konto & Umlauf
          </button>
          <button
            onClick={() => setActiveTab('marketplace')}
            className={`py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'marketplace'
                ? 'border-[var(--color-gemeinwohl-primary)] text-[var(--color-gemeinwohl-primary)]'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            Marktplatz & Tausch
          </button>
          <button
            onClick={() => setActiveTab('impact')}
            className={`py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'impact'
                ? 'border-[var(--color-gemeinwohl-primary)] text-[var(--color-gemeinwohl-primary)]'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            Regeln & Wirkung
          </button>
        </div>
      </header>

      {/* HAUPTINHALT */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        {activeTab === 'wallet' && (
          <div className="space-y-8 animate-fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Balance card */}
              <div className="md:col-span-2 bg-[var(--color-gemeinwohl-primary)] text-white p-8 rounded-3xl shadow-lg relative overflow-hidden flex flex-col justify-between">
                <div className="absolute right-0 top-0 translate-x-6 -translate-y-6 w-48 h-48 bg-white/5 rounded-full pointer-events-none" />
                <div className="absolute right-12 bottom-4 w-32 h-32 bg-white/5 rounded-full pointer-events-none" />
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xs md:text-sm font-semibold text-emerald-100 uppercase tracking-wider flex items-center gap-1.5">
                      <Coins className="w-4 h-4 text-emerald-200" /> Aktueller Punktestand (GWP)
                    </span>
                    <span className="text-xs bg-black/20 px-3 py-1 rounded-full text-emerald-200 flex items-center gap-1.5 font-medium">
                      <Clock className="w-3.5 h-3.5" /> Noch {FREE_DAYS_LEFT} Tage frei von Umlaufprämie
                    </span>
                  </div>
                  <div className="flex items-baseline gap-3 my-2">
                    <span className="text-5xl md:text-6xl font-black tracking-tight">
                      {USER_BALANCE.toFixed(2)}
                    </span>
                    <span className="text-2xl font-bold text-emerald-200">GWP</span>
                  </div>
                  <div className="mt-3 text-xs text-emerald-100/90 bg-black/15 p-3 rounded-2xl flex flex-col gap-1">
                    <div className="flex justify-between">
                      <span>Rang-Obergrenze (Rank Cap):</span>
                      <span className="font-semibold">{RANK_CAP.toFixed(2)} GWP</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Umlauf-Status nach 30 Tagen:</span>
                      <span className="font-semibold text-amber-200">{DEMURRAGE_RATE}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Geschütztes 30-Tage-Fenster:</span>
                      <span className="font-semibold">45.00 GWP</span>
                    </div>
                    <div className="flex justify-between">
                      <span>In progressiver Umlaufprämie:</span>
                      <span className="font-semibold">295.50 GWP</span>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap gap-4">
                  <button
                    onClick={() => setShowQrModal(true)}
                    className="flex-1 bg-white text-[var(--color-gemeinwohl-primary)] px-5 py-3 rounded-xl font-semibold hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                  >
                    <QrCode className="w-5 h-5" /> QR-Code (Zahlen / Empfangen)
                  </button>
                  <button className="bg-white/10 hover:bg-white/20 text-white px-5 py-3 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer">
                    <ArrowLeftRight className="w-5 h-5" /> Überweisen & Tauschen
                  </button>
                </div>
              </div>

              {/* Role profile card */}
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-200/60 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Akteurs-Profil</h3>
                  <p className="text-xs text-gray-500">Aktive Berechtigungen für deine Rolle.</p>
                </div>
                <div className="space-y-3 text-sm">
                  <div className={`p-3.5 rounded-2xl ${roleTone.bg} ${roleTone.text} border ${roleTone.border}`}>
                    <p className="font-semibold mb-1">{roleDesc.title}</p>
                    <p className="text-xs opacity-80">{roleDesc.body}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Transaction history */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-200/60">
              <h3 className="font-bold text-lg text-gray-900 mb-4">Transaktionsverlauf</h3>
              <div className="space-y-3">
                {RECENT_TRANSACTIONS.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-4 rounded-2xl hover:bg-gray-50 transition-colors border border-gray-100"
                  >
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${
                          tx.type === 'receive'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        {tx.type === 'receive' ? '↓' : '↑'}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">{tx.partner}</h4>
                        <p className="text-xs text-gray-500">
                          {tx.date} •{' '}
                          <span className="text-[var(--color-gemeinwohl-primary)] font-medium">
                            {tx.category}
                          </span>
                        </p>
                      </div>
                    </div>
                    <div
                      className={`font-bold text-base ${
                        tx.type === 'receive' ? 'text-emerald-600' : 'text-gray-700'
                      }`}
                    >
                      {tx.amount} GWP
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'marketplace' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-3xl shadow-sm border border-gray-200/60">
              <div>
                <h3 className="font-bold text-lg text-gray-900">Regionaler Marktplatz</h3>
                <p className="text-xs text-gray-500">
                  Jedes Ding & jede Dienstleistung in GWP oder gleichwertigem Tausch.
                </p>
              </div>
              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-[var(--color-gemeinwohl-primary)] text-white px-4 py-2.5 rounded-xl font-semibold text-sm hover:bg-[var(--color-gemeinwohl-primary-dark)] transition-colors flex items-center gap-2 cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" /> Neues Angebot / Suche erstellen
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              <FilterButton
                active={marketplaceFilter === 'all'}
                onClick={() => setMarketplaceFilter('all')}
              >
                Alle anzeigen
              </FilterButton>
              <FilterButton
                active={marketplaceFilter === 'search'}
                onClick={() => setMarketplaceFilter('search')}
                icon={Search}
              >
                Ich suche nach...
              </FilterButton>
              <FilterButton
                active={marketplaceFilter === 'gift'}
                onClick={() => setMarketplaceFilter('gift')}
                icon={Gift}
              >
                Zu verschenken
              </FilterButton>
              <FilterButton
                active={marketplaceFilter === 'service'}
                onClick={() => setMarketplaceFilter('service')}
                icon={Briefcase}
              >
                Dienstleistungen
              </FilterButton>
              <FilterButton
                active={marketplaceFilter === 'goods'}
                onClick={() => setMarketplaceFilter('goods')}
                icon={Wallet}
              >
                Waren
              </FilterButton>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredItems.length === 0 ? (
                <div className="md:col-span-2 bg-white rounded-3xl p-12 shadow-sm border border-gray-200/60 text-center text-gray-400">
                  Keine Einträge in dieser Kategorie.
                </div>
              ) : (
                filteredItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white p-6 rounded-3xl shadow-sm border border-gray-200/60 flex flex-col justify-between space-y-4 hover:shadow-md transition-shadow"
                  >
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-xs bg-emerald-50 text-[var(--color-gemeinwohl-primary)] font-medium px-2.5 py-1 rounded-full">
                          {item.category}
                        </span>
                        <span className="text-xs text-gray-400 flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {item.location}
                        </span>
                      </div>
                      <h4 className="font-bold text-gray-800 text-base">{item.title}</h4>
                      <p className="text-xs text-gray-500 mt-1">Anbieter: {item.author}</p>
                    </div>
                    <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
                      <div>
                        <p className="text-xs text-gray-400">Preis / Tauschbasis</p>
                        <p className="font-bold text-emerald-700 text-sm">{item.price}</p>
                      </div>
                      <button className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-4 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1">
                        Anfragen / Tauschen <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'impact' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-200/60 space-y-6">
              <h3 className="font-bold text-xl text-gray-900">Regeln & Wirkungsweise des Protokolls</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <RuleCard
                  icon={TrendingDown}
                  title="1. Gestaffelte Demurrage (Umlaufprämie)"
                  body="Punkte sind nach Erhalt exakt 30 Tage lang gebührenfrei. Werden sie danach nicht eingesetzt, greift eine progressive Umlaufbelastung. Dies verhindert das Horten von Kapital und stärkt die Region."
                />
                <RuleCard
                  icon={Building2}
                  title="2. Institutionen & Soziale Rollen"
                  body="Institutionen bilden reale Entscheidungssituationen ab (z. B. Begleichung von Verwaltungsgebühren oder Strafen über Punkte). Soziale Einrichtungen koordinieren offline-Hilfen direkt im Verbund."
                />
                <RuleCard
                  icon={Handshake}
                  title="3. Regionaler Marktplatz & Tausch"
                  body="Alle gängigen Kategorien (Dienstleistungen, Güter, Lebensmittel) mit festen Pflicht-Filtern: „Ich suche nach...“ und „Zu verschenken“. Alles flexibel in GWP oder gegen gleichwertige Sach-/Dienstleistungen."
                />
                <RuleCard
                  icon={Leaf}
                  title="4. Gemeinwohl-Orientierung"
                  body="Das Protokoll fördert Kreislaufwirtschaft, Nachbarschaftshilfe und regionale Wertschöpfung im Yspertal durch naturnahe Anreizmechanismen statt Wachstumsdruck."
                />
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-gray-200 mt-8">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between text-xs text-gray-500">
          <span className="flex items-center gap-2">
            <Leaf className="w-4 h-4 text-[var(--color-gemeinwohl-secondary)]" />
            Gemeinwohl-Protokoll · Regionales Ökosystem Yspertal
          </span>
          <span>Demonstration · Demo-Daten</span>
        </div>
      </footer>

      {showQrModal && <QrModal onClose={() => setShowQrModal(false)} balance={USER_BALANCE} />}
      {showCreateModal && <CreateModal onClose={() => setShowCreateModal(false)} onCreate={handleCreate} />}
    </div>
  );
}

function FilterButton({
  active,
  onClick,
  children,
  icon: Icon,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  icon?: typeof Search;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
        active
          ? 'bg-[var(--color-gemeinwohl-primary)] text-white shadow-sm'
          : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300'
      }`}
    >
      {Icon && <Icon className="w-3.5 h-3.5 inline mr-1" />}
      {children}
    </button>
  );
}

function RuleCard({ icon: Icon, title, body }: { icon: typeof Users; title: string; body: string }) {
  return (
    <div className="p-5 rounded-2xl bg-gray-50 border border-gray-100 space-y-3">
      <div className="w-9 h-9 rounded-lg bg-[var(--color-gemeinwohl-primary)]/10 text-[var(--color-gemeinwohl-primary)] flex items-center justify-center">
        <Icon className="w-5 h-5" />
      </div>
      <h4 className="font-semibold text-gray-800">{title}</h4>
      <p className="text-sm text-gray-600 leading-relaxed">{body}</p>
    </div>
  );
}

export default App;
