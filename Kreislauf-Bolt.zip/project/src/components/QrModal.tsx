import { QrCode, X, Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface QrModalProps {
  onClose: () => void;
  balance: number;
}

export default function QrModal({ onClose, balance }: QrModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(`GWP:${balance.toFixed(2)}`).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-6 relative animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
        <div className="text-center space-y-2">
          <h3 className="font-bold text-xl text-gray-900">Dein Gemeinwohl-QR-Code</h3>
          <p className="text-xs text-gray-500">
            Zum sekundenschnellen Überweisen und Empfangen vor Ort.
          </p>
        </div>
        <div className="bg-gray-50 p-8 rounded-2xl flex items-center justify-center border border-dashed border-gray-300">
          <QrCode className="w-40 h-40 text-[var(--color-gemeinwohl-primary)]" strokeWidth={1.5} />
        </div>
        <button
          onClick={handleCopy}
          className="w-full flex items-center justify-center gap-2 text-xs text-gray-500 hover:text-gray-700 cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-600" /> Kopiert
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" /> GWP-Kennung kopieren
            </>
          )}
        </button>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 bg-[var(--color-gemeinwohl-primary)] text-white py-3 rounded-xl font-semibold text-sm cursor-pointer hover:bg-[var(--color-gemeinwohl-primary-dark)] transition-colors"
          >
            Schließen
          </button>
        </div>
      </div>
    </div>
  );
}
