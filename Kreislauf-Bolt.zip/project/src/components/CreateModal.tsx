import { X } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import type { MarketplaceItem } from '@/App';

interface CreateModalProps {
  onClose: () => void;
  onCreate: (data: { title: string; type: MarketplaceItem['type']; price: string }) => void;
}

const TYPE_OPTIONS: { value: MarketplaceItem['type']; label: string }[] = [
  { value: 'search', label: 'Ich suche nach...' },
  { value: 'gift', label: 'Zu verschenken' },
  { value: 'service', label: 'Dienstleistung' },
  { value: 'goods', label: 'Ware / Produkt' },
];

export default function CreateModal({ onClose, onCreate }: CreateModalProps) {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<MarketplaceItem['type']>('search');
  const [price, setPrice] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !price.trim()) return;
    onCreate({ title: title.trim(), type, price: price.trim() });
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl space-y-6 relative animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
        <div>
          <h3 className="font-bold text-xl text-gray-900">Neues Angebot oder Suche erstellen</h3>
          <p className="text-xs text-gray-500">
            Biete Gegenstände, Dienstleistungen oder suche nach Hilfe.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block font-medium text-gray-700 mb-1">Titel / Bezeichnung</label>
            <input
              type="text"
              placeholder="z.B. Suche Bohrmaschine für Wochenende"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-emerald-600 focus:border-emerald-600 transition-colors"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-medium text-gray-700 mb-1">Kategorie / Typ</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as MarketplaceItem['type'])}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-emerald-600 focus:border-emerald-600 transition-colors"
              >
                {TYPE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium text-gray-700 mb-1">Preis / Tauschbasis</label>
              <input
                type="text"
                placeholder="z.B. 15 GWP oder Tausch"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-emerald-600 focus:border-emerald-600 transition-colors"
                required
              />
            </div>
          </div>
          <div className="pt-2 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 py-3 rounded-xl font-semibold cursor-pointer transition-colors"
            >
              Abbrechen
            </button>
            <button
              type="submit"
              className="flex-1 bg-[var(--color-gemeinwohl-primary)] text-white py-3 rounded-xl font-semibold cursor-pointer hover:bg-[var(--color-gemeinwohl-primary-dark)] transition-colors"
            >
              Veröffentlichen
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
